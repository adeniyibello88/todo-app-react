self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a84fcb792748b2e90d2d862f66a5c5ba",
    "url": "/react-todo-app/index.html"
  },
  {
    "revision": "4caf1956538fe36e49c0",
    "url": "/react-todo-app/static/css/2.d9ad5f5c.chunk.css"
  },
  {
    "revision": "46480cb5f08d5fbf5c45",
    "url": "/react-todo-app/static/css/main.6e0a98a1.chunk.css"
  },
  {
    "revision": "4caf1956538fe36e49c0",
    "url": "/react-todo-app/static/js/2.fbd5e2df.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/react-todo-app/static/js/2.fbd5e2df.chunk.js.LICENSE.txt"
  },
  {
    "revision": "46480cb5f08d5fbf5c45",
    "url": "/react-todo-app/static/js/main.28881ab1.chunk.js"
  },
  {
    "revision": "7f607c3e693deaba8e3a",
    "url": "/react-todo-app/static/js/runtime-main.93dbfc51.js"
  }
]);